//
//  HomeViewController.swift
//  SideMenuDemo
//
//  Created by Muhammad Kamran on 7/12/17.
//  Copyright © 2017 Muhammad Kamran. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

    static let language = "AR"
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let button = UIBarButtonItem(title: "Home", style: .plain, target: self, action: #selector(HomeViewController.homeAction))
        if HomeViewController.language == "EN" {
            self.navigationItem.leftBarButtonItem = button
        } else {
            self.navigationItem.rightBarButtonItem = button
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func homeAction() {
        if HomeViewController.language == "EN" {
            self.slideMenuController()?.openLeft()
        } else {
            self.slideMenuController()?.openRight()
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
