//
//  ViewController.swift
//  SideMenuDemo
//
//  Created by Muhammad Kamran on 7/12/17.
//  Copyright © 2017 Muhammad Kamran. All rights reserved.
//

import UIKit
import SlideMenuControllerSwift

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func homeAction(_ sender: Any) {
        let main = UIStoryboard.init(name:"Main", bundle: nil)
        let homeVC = main.instantiateViewController(withIdentifier: "HomeViewControllerID") as! HomeViewController
        let sliderVC = main.instantiateViewController(withIdentifier: "SliderViewControllerID") as! SliderViewController
        let navigationVC: UINavigationController = UINavigationController(rootViewController: homeVC)
        
        var slideMenuController:SlideMenuController
        if HomeViewController.language == "EN" {
            slideMenuController = SlideMenuController(mainViewController: navigationVC, leftMenuViewController: sliderVC)
        } else {
            slideMenuController = SlideMenuController(mainViewController: navigationVC, rightMenuViewController: sliderVC)
        }
//        if LKManager.sharedInstance().currentLanguage.direction == .rightToLeft {
//            navigationVC.navigationBar.flip()
//            leftSliderVC.view.flip()
//            slideMenuController.view.flip()
//        }
        (UIApplication.shared.delegate as! AppDelegate).window?.rootViewController = slideMenuController
    }

}

