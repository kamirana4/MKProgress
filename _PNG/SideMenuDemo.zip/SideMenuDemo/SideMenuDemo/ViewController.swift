//
//  ViewController.swift
//  SideMenuDemo
//
//  Created by Muhammad Kamran on 7/12/17.
//  Copyright © 2017 Muhammad Kamran. All rights reserved.
//

import UIKit
import SlideMenuControllerSwift

class ViewController: UIViewController {

    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.navigationBar.isHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        button.setTitle("Home Button", for: .normal)
        button.transform = CGAffineTransform.identity
        
        navigationController?.navigationBar.isHidden = false
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    
        animate(view: imageView, delay: 0.2)
        animate(view: label1, delay: 0.5)
        animate(view: label2, delay: 0.8)
        animate(view: button, delay: 1.1)
        
    }
    
    private func animate(view: UIView, duration: TimeInterval = 2, delay: Double) {
        view.transform = CGAffineTransform(translationX: 0, y: 160)
        view.layer.opacity = 0.0
        
        UIView.animate(withDuration: duration, delay: delay, usingSpringWithDamping: 0.65, initialSpringVelocity: 1.0, options: .curveEaseOut, animations: {
            view.transform = CGAffineTransform.identity
            view.layer.opacity = 1.0
        }) { (success) in
            
        }
    }
    
    private func makeButtonTransitionEffect() {
        self.button.setTitle("", for: .normal)
        UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 0.0, options: .curveEaseOut, animations: {
            self.button.transform = CGAffineTransform(scaleX: 2.0, y: 1.0)
        }) { (success) in
            UIView.animate(withDuration: 1.0, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: .curveEaseOut, animations: {
                self.button.transform = CGAffineTransform(scaleX: 2.0, y: 25.0)
            }) { (success) in
                let main = UIStoryboard.init(name:"Main", bundle: nil)
                let sliderVC = main.instantiateViewController(withIdentifier: "SliderViewControllerID") as! SliderViewController
                self.navigationController?.pushViewController(sliderVC, animated: true)
            }
        }
    }
    
    
    
    @IBAction func homeAction(_ sender: Any) {
        makeButtonTransitionEffect()
    }
}

